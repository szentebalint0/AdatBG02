DROP TABLE IF EXISTS UGYFEL_MASKED;

CREATE TABLE UGYFEL_MASKED (
  LOGIN NVARCHAR(50),
  EMAIL NVARCHAR(50) MASKED WITH (FUNCTION = 'email()'),
  NEV NVARCHAR(50) MASKED WITH (FUNCTION = 'partial(1,"********",1)'),
  SZULEV INT,
  NEM NVARCHAR(2),
  CIM NVARCHAR(50) MASKED WITH (FUNCTION = 'default()')
);


-- Ez az eredeti feladat megoldása, a másikat online editorban nem tudtam futtatni, nem lehet dinamikusan maszkolni ott, csak írtam függvényeket, hogy vizuálisan is szemléltessem