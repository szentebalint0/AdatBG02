DROP TABLE IF EXISTS UGYFEL_MASKED;

CREATE TABLE UGYFEL_MASKED (
  LOGIN NVARCHAR(255),
  EMAIL NVARCHAR(255) MASKED WITH (FUNCTION = 'email()'),
  NEV NVARCHAR(255) MASKED WITH (FUNCTION = 'partial(1,"********",1)'),
  SZULEV INT,
  NEM NVARCHAR(10),
  CIM NVARCHAR(255) MASKED WITH (FUNCTION = 'default()')
);


-- Ez az eredeti feladat megoldása, a másikat online editorban nem tudtam futtatni, nem lehet dinamikusan maszkolni ott, csak írtam függvényeket, hogy vizuálisan is szemléltessem