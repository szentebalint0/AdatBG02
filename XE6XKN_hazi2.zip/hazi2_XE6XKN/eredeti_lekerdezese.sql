SELECT *
FROM UGYFEL

-- csv-ből lett importálva az oldalra